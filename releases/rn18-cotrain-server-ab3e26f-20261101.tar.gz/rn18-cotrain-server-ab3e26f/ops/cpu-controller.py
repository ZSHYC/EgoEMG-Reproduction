from pathlib import Path
import datetime,hashlib,json,os,sys,time
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from egoemg_repro.emg2pose_memory_process import run_owned_stage,same_process,process_identity
from egoemg_repro.classic_emg_cohort import _StatGuard
q=json.loads((R/'private/request.json').read_text());m=json.loads((R/'private/stage-receipt.json').read_text());parent=process_identity(os.getppid());began=time.monotonic()
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
pins=_StatGuard([*[R/n for n in m['files_sha256']],R/'private/stage-receipt.json'])
def guard():
 assert'torch'not in sys.modules and same_process(parent)and os.environ.get('CUDA_VISIBLE_DEVICES')=='';pins.check()
for n,h in m['files_sha256'].items():assert sha(R/n)==h,n
owned=[]
base=[sys.executable,'-u','-B','-m','egoemg_repro.rn18_initializer_train','fit','--data',str(R/'private/engineering'),'--upstream',q['upstream'],'--output',str(R/'private/fit'),'--scope','cpu_engineering']
commands=[('setup',[sys.executable,'-B',str(R/'private/cpu-cli.py'),'setup']),('prefix',base+['--stop-after-epoch','1']),('prefix-audit',[sys.executable,'-B',str(R/'private/cpu-cli.py'),'prefix-audit']),('resume',base+['--resume']),('export',[sys.executable,'-B',str(R/'private/cpu-cli.py'),'export']),('reopen',[sys.executable,'-B',str(R/'private/cpu-cli.py'),'reopen'])]
for name,command in commands:
 guard();print(json.dumps(dict(phase=name,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())),flush=True)
 stage=run_owned_stage(command,R/('private/owned-'+name),descriptors={},guard=guard,environment=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1'),poll_seconds=2.,terminate_grace=5.)
 assert stage['status']=='success'and stage['worker_exit_code']==0 and stage['all_owned_consumers_exited']and all(not same_process(stage[k])for k in('worker','guardian'))
 owned.append(dict(name=name,result=stage));guard()
a=json.loads((R/'private/phase-export.json').read_text());b=json.loads((R/'private/phase-reopen.json').read_text());assert {k:v for k,v in a.items()if k!='phase'}=={k:v for k,v in b.items()if k!='phase'}
for n,h in m['files_sha256'].items():assert sha(R/n)==h,n
files={str(p.relative_to(R/'private')):sha(p)for p in(R/'private').glob('phase-*.json')};files.update({str(p.relative_to(R/'private')):sha(p)for p in(R/'private/fit').rglob('*')if p.is_file()});files['selected-best.pt']=sha(R/'private/selected-best.pt')
guard();v=dict(format='actual_rn18_cotrain_native_cpu_recovery_export_v1',source_commit=m['source_commit'],bundle_sha256=m['bundle_sha256'],actual_owned_stages=owned,original_native_fit_result=b['result'],fit_identity=b['fit_identity'],selected_export=b['export'],files_sha256=files,all_110_native_tensors_exact=True,actual_six_state_restoration_verified=True,actual_full_validation_replay_exact=True,actual_prefix_epochs=1,actual_final_engineering_epochs=2,actual_optimizer_updates=4,partial_export_rejected=True,engineering_rejected_as_full=True,all_owned_consumers_exited=True,all_capsule_sources_after_exit_exact=True,cuda_initialized=False,trained_full_initializer_complete=False,scientific_settings_added=0,full_paper_complete=False,seconds=time.monotonic()-began)
with(R/'private/workflow-result.json').open('x')as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(status='native-cpu-recovery-export-closed',six_state_restoration_verified=True,full_initializer=False)),flush=True)
