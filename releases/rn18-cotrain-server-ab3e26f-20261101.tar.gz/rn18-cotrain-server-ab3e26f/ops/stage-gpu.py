from pathlib import Path
import base64,datetime,hashlib,json,os,shutil,subprocess,sys,time
q=json.load(sys.stdin);root=Path('/data/shihao/egoemg-rn18-cotrain-original-full-cli-20261101');D=Path('/data/shihao/egoemg-rn18-cotrain-full-inputs-fixed-20261101');P=Path('/data/shihao/egoemg-native-resnet18-full-cli-20261101')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def live(i):
 p=Path('/proc',str(i['pid']))
 try:z=(p/'stat').read_text().rsplit(')',1)[1].split();return z[19]==str(i['start_ticks'])and z[0]!='Z'and p.stat().st_uid==os.getuid()
 except FileNotFoundError:return False
assert not root.exists(),'inspect existing original handles; no implicit retry'
review=q['review'];assert review['all_important_fixed']and review['critical_remaining']==review['important_remaining']==0
state=json.loads((D/'private/execution-state.json').read_text());data=json.loads((D/'private/workflow-result.json').read_text());dm=json.loads((D/'private/stage-receipt.json').read_text())
assert state['status']=='complete'and state['actual_exit_code']==0 and all(not live(state[k])for k in('wrapper','child'))
assert data['actual_full_legacy_admissions']==2 and data['all_owned_consumers_exited']
for stage in data['actual_owned_stages']:
 assert stage['status']=='success'and stage['worker_exit_code']==0 and stage['all_owned_consumers_exited']and all(not live(stage[k])for k in('worker','guardian'))
for n,h in dm['files_sha256'].items():assert sha(D/n)==h,n
cohort=json.loads((D/'private/full-a.json').read_text());assert cohort==data['full_identity']and cohort['registered_full_legacy']and cohort['counts']==dict(train=62470,val=1052)
ps=json.loads((P/'private/execution-state.json').read_text());pm=json.loads((P/'private/stage-receipt.json').read_text())
assert pm['bundle_sha256']=='dce0027c3da6f348aff0971c38a621f3a58fc9aa66dc7e97528f48fc270ea361'
assert ps['status']=='running'and all(live(ps[k])for k in('wrapper','child'))or ps['status']=='complete'and ps['actual_exit_code']==0
inventory={int(row.split(',')[0]):row.split(',')[1].strip()for row in subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid','--format=csv,noheader,nounits'],text=True).splitlines()}
files={n:base64.b64decode(b)for n,b in q['files'].items()}
for n,h in review['final_source_files_sha256'].items():assert hashlib.sha256(files[n]).hexdigest()==h,n
for n,b in files.items():
 if n.startswith('egoemg_repro/'):assert hashlib.sha256(b).hexdigest()==dm['files_sha256'][n],n
req=json.loads((D/'private/request.json').read_text());req.update(variant='rn18-compatible-cotrain-small',gpu_index=0,gpu_uuid=inventory[0],predecessor_root=str(P),predecessor_handles={k:ps[k]for k in('wrapper','child')},predecessor_bundle_sha256=pm['bundle_sha256'],registered_data_bundle_sha256=dm['bundle_sha256'],no_automatic_retry=True,deadline_seconds=None,original_batch=260,original_workers=12,required_full_epochs=150)
files.update({'private/request.json':(json.dumps(req,sort_keys=True,indent=2)+'\n').encode(),'private/registered-cohort.json':(D/'private/full-a.json').read_bytes(),'private/review-and-fixes.json':(json.dumps(review,sort_keys=True,indent=2)+'\n').encode()})
assert shutil.disk_usage('/data').free>25*1024**3;root.mkdir(mode=0o700)
for n,b in files.items():
 if n.endswith('.py'):compile(b,n,'exec')
 p=root/n;p.parent.mkdir(parents=True,exist_ok=True,mode=0o700);p.write_bytes(b);p.chmod(0o600)
body=dict(source_commit=q['source_commit'],files_sha256={n:hashlib.sha256(b).hexdigest()for n,b in files.items()},full_paper_complete=False)
bundle=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest();(root/'private/stage-receipt.json').write_text(json.dumps(dict(body,bundle_sha256=bundle),sort_keys=True,indent=2)+'\n')
for n,h in body['files_sha256'].items():assert sha(root/n)==h,n
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root)+':/home/shihao/projects/EgoEMG-Classic-Canonical-20261026/.deps')
with(root/'private/recorder.stdout').open('xb')as log:child=subprocess.Popen(['/home/shihao/projects/EgoEMG-Reproduction/.runtime/env/bin/python','-u','-B',str(root/'private/recorder.py')],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
for _ in range(200):
 if(root/'private/execution-state.json').exists():break
 assert child.poll()is None;time.sleep(.05)
actual=json.loads((root/'private/execution-state.json').read_text());assert actual['wrapper']['pid']==child.pid and all(live(actual[k])for k in('wrapper','child'))
print(json.dumps(dict(root=str(root),source_commit=q['source_commit'],bundle_sha256=bundle,actual_state=actual,actual_matching_owners_live=True,gpu_index=0,gpu_uuid=inventory[0],exact_predecessor_root=str(P),exact_predecessor_handles=req['predecessor_handles'],native_batch=260,native_workers=12,precision='bf16-mixed',full_epochs=150,full_updates=36150,qualification_complete=False,full_fit_started=False,scientific_settings_added=0,full_paper_complete=False,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())))
