from pathlib import Path
import json,os,random,resource,sys,time
import numpy as np
import torch
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R));sys.path.insert(0,str(R/'tests'))
q=json.loads((R/'private/request.json').read_text());label=sys.argv[1]
if label=='setup':
 from test_emg_initializer_data import source
 p=R/'private/engineering';p.mkdir(mode=0o700);source(p,optional_labels=True)
 print(json.dumps(dict(action='setup',actual_learned_models_constructed=0,optimizer_updates=0,cuda_initialized=torch.cuda.is_initialized())),flush=True);raise SystemExit(0)
from egoemg_repro.emg_initializer_literal import compose_emg_initializer,emg_initializer_normalization
from egoemg_repro.rn18_initializer_cohort import admit_rn18_initializer_cohort
cfg=compose_emg_initializer(q['upstream']);norm=emg_initializer_normalization(q['upstream']);py=random.getstate();ns=np.random.get_state();ts=torch.get_rng_state().clone()
def deny(*a,**k):raise RuntimeError('input admission cannot construct neural module or optimizer')
torch.nn.Module.__init__=deny;torch.optim.AdamW.__init__=deny;torch.optim.Adam.__init__=deny
full=label.startswith('full-');data=Path(q['data'])if full else R/'private/engineering'
expected=json.loads((R/('private/'+label[:-1]+'a.json')).read_text())if label.endswith('-b')else None
began=time.monotonic();c=admit_rn18_initializer_cohort(data,upstream=q['upstream'],config=cfg,normalization=norm,expected=expected,require_full=full)
assert set(c.datasets)=={'train','val'}and all(not view._center_target_only for ds in c.datasets.values()for view in ds.views)
assert c.identity['registered_full_legacy']is full
if full:assert c.identity['counts']==dict(train=62470,val=1052)and c.identity['future_fusion_partition_content_sha256']=='44e9ebc8a2f63a79699c5a976bf2717b0fe7a376427c7c46f538d0745c2b4bd0'
assert random.getstate()==py and ns[0]==np.random.get_state()[0]and np.array_equal(ns[1],np.random.get_state()[1])and ns[2:]==np.random.get_state()[2:]
assert torch.equal(ts,torch.get_rng_state())and not torch.cuda.is_initialized();c.check()
with(R/('private/'+label+'.json')).open('x')as f:json.dump(c.identity,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(action=label,identity_sha256=c.identity['sha256'],counts=c.identity['counts'],payload_files=c.identity['payload_file_count'],raw_bytes=sum(c.identity['payload_file_bytes'].values()),
 actual_learned_models_constructed=0,optimizer_constructions=0,optimizer_updates=0,cuda_initialized=False,all_three_rng_domains_unchanged=True,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,seconds=time.monotonic()-began)),flush=True)
