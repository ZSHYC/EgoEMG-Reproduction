from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from egoemg_repro.emg2pose_memory_process import run_owned_stage,same_process,process_identity
from egoemg_repro.classic_emg_cohort import _StatGuard,_source_paths
q=json.loads((R/'private/request.json').read_text());m=json.loads((R/'private/stage-receipt.json').read_text());parent=process_identity(os.getppid());started=time.monotonic();phase='waiting';cpu=True;owned=[];observed={}
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,value):
 with(R/'private'/name).open('x')as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def live(i):
 p=Path('/proc',str(i['pid']))
 try:z=(p/'stat').read_text().rsplit(')',1)[1].split();return z[19]==str(i['start_ticks'])and z[0]!='Z'and p.stat().st_uid==os.getuid()
 except FileNotFoundError:return False
for n,h in m['files_sha256'].items():assert sha(R/n)==h,n
pins=_StatGuard([*[R/n for n in m['files_sha256']],R/'private/stage-receipt.json',Path(q['data'])/'metadata.npz',Path(q['data'])/'manifest.json',*_source_paths(Path(q['upstream']))])
def gpu():
 row=subprocess.check_output(['nvidia-smi','-i',q['gpu_uuid'],'--query-gpu=uuid,name,memory.free','--format=csv,noheader,nounits'],text=True,timeout=15).strip().split(',')
 assert row[0].strip()==q['gpu_uuid']and row[1].strip()=='NVIDIA A800-SXM4-80GB'
 apps=[]
 for line in subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader,nounits'],text=True,timeout=15).splitlines():
  pid,uuid=[x.strip()for x in line.split(',')]
  if uuid==q['gpu_uuid']:apps.append(int(pid))
 return int(row[2].strip())*1024**2,apps
def guard():
 assert'torch'not in sys.modules and same_process(parent);pins.check()
 assert shutil.disk_usage('/data').free>25*1024**3
 assert int(next(x.split()[1]for x in Path('/proc/meminfo').read_text().splitlines()if x.startswith('MemAvailable:')))*1024>128*1024**3
 if phase.startswith('waiting'):return
 free,apps=gpu();assert free>8*1024**3,'assigned GPU reserve exhausted'
 p=R/('private/owned-'+phase+'/started.json');owner=json.loads(p.read_text())['worker']if p.exists()else None
 for pid in apps:
  assert not cpu and owner is not None and same_process(owner)and pid==owner['pid'],'foreign GPU arrival; stop owned attempt only'
  observed[phase]=dict(worker=owner,actual_nvml_pid=pid,gpu_uuid=q['gpu_uuid'],observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
P=Path(q['predecessor_root']);expected=q['predecessor_handles'];print(json.dumps(dict(phase='waiting-exact-predecessor',variant=q['variant'],handles=expected,deadline_seconds=None)),flush=True)
while True:
 guard();state=json.loads((P/'private/execution-state.json').read_text());assert all(state[k]==expected[k]for k in('wrapper','child')),'predecessor handle changed'
 if state['status']!='running':break
 assert all(live(expected[k])for k in('wrapper','child')),'predecessor missing with nonterminal state'
 time.sleep(5)
assert state['status']=='complete'and state['actual_exit_code']==0 and all(not live(expected[k])for k in('wrapper','child'))
pm=json.loads((P/'private/stage-receipt.json').read_text());assert pm['bundle_sha256']==q['predecessor_bundle_sha256']
closed=[]
for path in sorted((P/'private').glob('owned-*/started.json')):
 stage=json.loads(path.with_name('stage-result.json').read_text());handles=json.loads(path.read_text())
 assert stage['status']=='success'and stage['worker_exit_code']==0 and stage['all_owned_consumers_exited']
 assert all(not same_process(handles[k])for k in('worker','guardian'));closed.append(str(path.parent.name))
assert closed
for n,h in pm['files_sha256'].items():assert sha(P/n)==h,n
write('actual-predecessor-closed.json',dict(actual_terminal_state=state,bundle_sha256=q['predecessor_bundle_sha256'],all_owned_stages_closed=closed))
phase='waiting-assigned-gpu';print(json.dumps(dict(phase=phase,gpu_uuid=q['gpu_uuid'],deadline_seconds=None)),flush=True)
while True:
 guard();free,apps=gpu()
 if not apps and free>64*1024**3:break
 time.sleep(5)
def invoke(name,args,is_cpu):
 global phase,cpu
 if not is_cpu:
  free,apps=gpu();assert not apps and free>64*1024**3,'assigned GPU must be idle with64GiB reserve'
 phase=name;cpu=is_cpu;guard();print(json.dumps(dict(phase=name,variant=q['variant'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat())),flush=True)
 stage=run_owned_stage([sys.executable,'-u','-B',*args],R/('private/owned-'+name),descriptors={},guard=guard,
  environment=dict(os.environ,CUDA_VISIBLE_DEVICES=''if cpu else q['gpu_uuid'],EGOEMG_NO_PRETRAINED_DOWNLOAD='0',PYTHONDONTWRITEBYTECODE='1'),poll_seconds=2.,terminate_grace=10.)
 assert stage['status']=='success'and stage['worker_exit_code']==0 and stage['all_owned_consumers_exited']and all(not same_process(stage[k])for k in('worker','guardian'))
 if not cpu:assert name in observed,'no actual owned NVML CUDA observation'
 owned.append(stage);guard();write('phase-'+name+'.json',dict(phase=name,actual_owned_stage=stage,actual_gpu_observation=observed.get(name),scientific_eligible=False,full_paper_complete=False))
qual=R/'private/qualification-fit';full=R/'private/full-fit'
fitbase=['-m','egoemg_repro.rn18_initializer_train','fit','--data',q['data'],'--upstream',q['upstream'],'--cohort-receipt',str(R/'private/registered-cohort.json')]
invoke('qual-prefix',[*fitbase,'--output',str(qual),'--scope','cuda_engineering','--stop-after-epoch','1'],False)
prefix=json.loads((qual/'fit-result.json').read_text());assert prefix['completed_epochs']==1 and prefix['optimizer_executions']==2 and not prefix['stage_complete']
write('qualification-prefix-result.json',prefix)
invoke('qual-resume',[*fitbase,'--output',str(qual),'--scope','cuda_engineering','--resume'],False)
for action in('export','reopen'):invoke('qual-'+action,[str(R/'private/cpu-accept.py'),'qual',action],True)
a=json.loads((R/'private/qual-export-result.json').read_text());b=json.loads((R/'private/qual-reopen-result.json').read_text())
assert {k:v for k,v in a.items()if k!='action'}=={k:v for k,v in b.items()if k!='action'}and not b['selected_export']['full_initializer']
write('qualified-original-batch.json',dict(actual_qualification=b,actual_nvml_observations=observed,original_batch=260,workers=12,actual_six_state_restoration_verified=True,actual_full_validation_replay_exact=True,formal_fit_started=False,full_paper_complete=False))
assert not full.exists(),'full producer must be fresh, never engineering weights'
invoke('full-fit',[*fitbase,'--output',str(full),'--scope','full'],False)
for action in('export','reopen'):invoke('full-'+action,[str(R/'private/cpu-accept.py'),'full',action],True)
a=json.loads((R/'private/full-export-result.json').read_text());b=json.loads((R/'private/full-reopen-result.json').read_text())
assert {k:v for k,v in a.items()if k!='action'}=={k:v for k,v in b.items()if k!='action'}and b['selected_export']['full_initializer']
assert len(owned)==7 and set(observed)=={'qual-prefix','qual-resume','full-fit'}
for n,h in m['files_sha256'].items():assert sha(R/n)==h,n
guard();write('workflow-result.json',dict(format='actual_rn18_cotrain_original_batch_qualification_and_full150_workflow_v1',source_commit=m['source_commit'],bundle_sha256=m['bundle_sha256'],actual_owned_stages=owned,actual_nvml_observations=observed,actual_selected_full_initializer=b,all_owned_consumers_exited=True,all_frozen_members_unchanged=True,parent_torch_unimported=True,trained_full_initializer_complete=True,scientific_settings_added=0,full_paper_complete=False,seconds=time.monotonic()-started))
print(json.dumps(dict(status='qualified-full150-native-initializer-and-export-complete',full_paper_complete=False)),flush=True)
