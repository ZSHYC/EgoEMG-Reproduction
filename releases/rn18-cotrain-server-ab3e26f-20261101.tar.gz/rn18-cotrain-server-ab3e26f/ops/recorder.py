"""Durable actual child exit status; no retry or scientific success inference."""
import datetime,json,os,signal,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
signal.signal(signal.SIGHUP,signal.SIG_IGN)
path=root/'private/execution-state.json'
def identity(pid):
 return {'pid':pid,'start_ticks':Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[19]}
def write(value):
 tmp=path.with_suffix('.writing')
 with tmp.open('w') as h:json.dump(value,h,sort_keys=True,indent=2);h.flush();os.fsync(h.fileno())
 tmp.replace(path)
with (root/'private/execution.log').open('xb') as log:
 process=subprocess.Popen([sys.executable,str(root/'private/runtime-probe.py')],
  stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 state=dict(status='running',wrapper=identity(os.getpid()),child=identity(process.pid),
  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),automatic_retry=False)
 write(state);code=process.wait()
state.update(status='complete' if code==0 else 'failed',actual_exit_code=code,
 ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(state)
sys.exit(code)
