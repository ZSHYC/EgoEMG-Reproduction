from pathlib import Path
import hashlib,json,os,sys
q=json.load(sys.stdin);r=Path(q['root']);sys.path.insert(0,str(r))
from egoemg_repro.emg2pose_memory_process import same_process
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def live(i):
 p=Path('/proc',str(i['pid']))
 try:z=(p/'stat').read_text().rsplit(')',1)[1].split();return z[19]==str(i['start_ticks'])and z[0]!='Z'and p.stat().st_uid==os.getuid()
 except FileNotFoundError:return False
s=json.loads((r/'private/execution-state.json').read_text());assert s['status']=='complete'and s['actual_exit_code']==0
assert all(s[k]==q['actual_state'][k]and not live(s[k])for k in('wrapper','child'))
m=json.loads((r/'private/stage-receipt.json').read_text());assert m['bundle_sha256']==q['bundle_sha256']==hashlib.sha256(json.dumps({k:v for k,v in m.items()if k!='bundle_sha256'},sort_keys=True,separators=(',',':')).encode()).hexdigest()
v=json.loads((r/'private/workflow-result.json').read_text());assert v['source_commit']==q['source_commit']and v['bundle_sha256']==m['bundle_sha256']
assert len(v['actual_owned_stages'])==6 and [x['name']for x in v['actual_owned_stages']]==['setup','prefix','prefix-audit','resume','export','reopen']
for x in v['actual_owned_stages']:
 t=x['result'];assert t['status']=='success'and t['worker_exit_code']==0 and t['all_owned_consumers_exited']
 assert all(not same_process(t[k])for k in('worker','guardian'))
for name,h in m['files_sha256'].items():assert sha(r/name)==h,name
for name,h in v['files_sha256'].items():assert sha(r/'private'/name)==h,name
import torch
from egoemg_repro.rn18_initializer_train import read_rn18_initializer_fit,read_rn18_initializer_export
def deny(*a,**kw):raise AssertionError('read-only collector cannot construct neural module/optimizer')
torch.nn.Module.__init__=deny;torch.optim.AdamW.__init__=deny;torch.optim.Adam.__init__=deny
F=r/'private/fit';fit=read_rn18_initializer_fit(F,require_full=False)
export=read_rn18_initializer_export(r/'private/selected-best.pt',source_fit=F,require_full=False)
assert fit==v['original_native_fit_result']and export==v['selected_export']
assert fit['completed_epochs']==2 and fit['optimizer_executions']==4 and fit['resume_start_exact']=={k:True for k in('model','optimizer','scheduler','callbacks','loops','rng')}and fit['resume_validation_exact']
assert fit['stage_complete']and not fit['full_training_terminated']and not fit['scientific_eligible']
assert len(export['tensor_inventory'])==110 and not export['full_initializer']
assert v['fit_identity']['cohort']['counts']==dict(train=340,val=4)
assert not v['fit_identity']['cohort']['registered_full_legacy']and v['fit_identity']['cohort']['future_holdout_overlap_rows']==dict(val=0,test=0)
assert v['all_110_native_tensors_exact']and v['partial_export_rejected']and v['engineering_rejected_as_full']and not v['trained_full_initializer_complete']
assert not torch.cuda.is_initialized()
print(json.dumps(dict(actual_terminal_state=s,raw_workflow=v,raw_workflow_file_sha256=sha(r/'private/workflow-result.json'),all_fourteen_original_owners_closed=True,all_capsule_and_output_bytes_after_exit_exact=True,fresh_post_exit_native_readers_exact=True,collector_neural_and_optimizer_constructors_denied=True,collector_cuda_initialized=False)))
