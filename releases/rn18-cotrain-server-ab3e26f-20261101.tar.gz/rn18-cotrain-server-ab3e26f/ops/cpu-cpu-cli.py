from pathlib import Path
import hashlib,json,os,sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R));sys.path.insert(0,str(R/'tests'))
phase=sys.argv[1];F=R/'private/fit';assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
if phase=='setup':
 from test_emg_initializer_data import source
 data=R/'private/engineering';data.mkdir(mode=0o700);source(data,optional_labels=True)
 v=dict(phase=phase,actual_learned_models_constructed=0,optimizer_updates=0,cuda_initialized=False)
else:
 import torch
 from egoemg_repro.rn18_initializer_train import read_rn18_initializer_fit,export_rn18_initializer_best,read_rn18_initializer_export
 from egoemg_repro.emg_initializer_runtime import emg_initializer_state_sha256
 if phase=='prefix-audit':
  result=read_rn18_initializer_fit(F,require_full=False)
  assert result['scope']=='cpu_engineering'and result['completed_epochs']==1 and result['optimizer_executions']==2 and not result['stage_complete']
  try:export_rn18_initializer_best(F,R/'private/partial-best.pt',require_full=False)
  except ValueError:pass
  else:raise AssertionError('partial engineering initializer was exported')
  assert not(R/'private/partial-best.pt').exists()
  (R/'private/prefix-result.json').write_bytes((F/'fit-result.json').read_bytes())
  v=dict(phase=phase,result=result,partial_export_rejected=True,fit_result_file_sha256=sha(F/'fit-result.json'),last_checkpoint_file_sha256=sha(F/'checkpoints/last.ckpt'),cuda_initialized=torch.cuda.is_initialized())
 else:
  result=read_rn18_initializer_fit(F,require_full=False);identity=json.loads((F/'identity.json').read_text())
  assert result['completed_epochs']==2 and result['optimizer_executions']==4 and result['stage_complete']and not result['full_training_terminated']
  assert result['resume_start_exact']=={k:True for k in('model','optimizer','scheduler','callbacks','loops','rng')}and result['resume_validation_exact']
  assert result['train_samples_per_epoch']==result['val_samples_per_epoch']==[4,4]
  assert identity['cohort']['counts']==dict(train=340,val=4)and identity['cohort']['future_holdout_overlap_rows']==dict(val=0,test=0)
  dest=R/'private/selected-best.pt'
  if phase=='export':receipt=export_rn18_initializer_best(F,dest,require_full=False)
  elif phase=='reopen':receipt=read_rn18_initializer_export(dest,source_fit=F,require_full=False)
  else:raise ValueError('known CPU recovery phase required')
  assert not receipt['full_initializer']and len(receipt['tensor_inventory'])==110
  for fn,args in((read_rn18_initializer_fit,(F,)),(read_rn18_initializer_export,(dest,))):
   try:fn(*args,**({}if fn is read_rn18_initializer_fit else dict(source_fit=F)))
   except ValueError:pass
   else:raise AssertionError('engineering passed the full producer gate')
  native=torch.load(str(F/'checkpoints'/result['selected_best']['file']),map_location='cpu',weights_only=False)
  exported=torch.load(str(dest),map_location='cpu',weights_only=False)
  assert set(exported['state_dict'])==set(native['state_dict'])==set(receipt['tensor_inventory'])
  assert all(torch.equal(exported['state_dict'][n],t)for n,t in native['state_dict'].items())
  assert emg_initializer_state_sha256(native['state_dict'])==receipt['state_sha256']
  assert receipt['source_fit_result_file_sha256']==sha(F/'fit-result.json')
  v=dict(phase=phase,result=result,fit_identity=identity,export=receipt,export_file_sha256=sha(dest),fit_result_file_sha256=sha(F/'fit-result.json'),all_110_native_tensors_exact=True,full_producer_gate_rejected_engineering=True,cuda_initialized=torch.cuda.is_initialized())
 assert not v['cuda_initialized']
with(R/('private/phase-'+phase+'.json')).open('x')as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(phase=phase,status='complete',cuda_initialized=False,scientific_eligible=False)),flush=True)
