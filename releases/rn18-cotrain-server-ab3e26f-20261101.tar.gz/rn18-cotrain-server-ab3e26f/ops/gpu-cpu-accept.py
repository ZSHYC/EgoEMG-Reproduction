from pathlib import Path
import hashlib,json,os,sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
import torch
from egoemg_repro.rn18_initializer_train import read_rn18_initializer_fit,export_rn18_initializer_best,read_rn18_initializer_export
family,action=sys.argv[1:];full=family=='full';F=R/('private/'+('full-fit'if full else'qualification-fit'));dest=R/('private/'+family+'-selected-best.pt')
assert os.environ.get('CUDA_VISIBLE_DEVICES')==''and not torch.cuda.is_initialized()
result=read_rn18_initializer_fit(F,require_full=full);identity=json.loads((F/'identity.json').read_text())
assert result['scope']==('full'if full else'cuda_engineering')and result['stage_complete']and result['full_training_terminated']is full
assert result['completed_epochs']==(150 if full else 2)and result['optimizer_executions']==(36150 if full else 4)
assert result['train_samples_per_epoch']==[62470 if full else 520]*(150 if full else 2)
assert result['val_samples_per_epoch']==[1052]*(150 if full else 2)
assert identity['cohort']['registered_full_legacy']and identity['cohort']['counts']==dict(train=62470,val=1052)
assert identity['cohort']['future_fusion_partition_content_sha256']=='44e9ebc8a2f63a79699c5a976bf2717b0fe7a376427c7c46f538d0745c2b4bd0'
assert identity['policy']['workers_by_role']==dict(train=12,val=12)and identity['policy']['batch_size_by_role']==dict(train=260,val=260)
assert identity['policy']['loader']['val_context']=='forkserver'and identity['policy']['effective_fingertip_weight']==.01
if not full:assert result['resume_start_exact']=={k:True for k in('model','optimizer','scheduler','callbacks','loops','rng')}and result['resume_validation_exact']
else:assert result['resume_start_exact']is None and result['resume_validation_exact']is None
receipt=export_rn18_initializer_best(F,dest,require_full=full)if action=='export'else read_rn18_initializer_export(dest,source_fit=F,require_full=full)
assert receipt['full_initializer']is full and len(receipt['tensor_inventory'])==110
with dest.open('rb')as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
value=dict(family=family,action=action,fit_result=result,fit_identity_sha256=identity['sha256'],selected_export=receipt,export_file_sha256=sha,scientific_eligible=False,full_paper_complete=False)
with(R/('private/'+family+'-'+action+'-result.json')).open('x')as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(family=family,action=action,completed_epochs=result['completed_epochs'],actual_native_tensors=110,full_initializer=full)),flush=True)
