from pathlib import Path
import base64,datetime,hashlib,json,os,subprocess,sys,time
q=json.load(sys.stdin);r=Path('/data/shihao/egoemg-rn18-cotrain-cpu-recovery-fixed-20261101');assert not r.exists(),'inspect original handles; no implicit restart'
r.mkdir(mode=0o700);files={n:base64.b64decode(b)for n,b in q['files'].items()}
for n,b in files.items():
 assert not Path(n).is_absolute()and'..'not in Path(n).parts
 if n.endswith('.py'):compile(b,n,'exec')
 p=r/n;p.parent.mkdir(parents=True,exist_ok=True,mode=0o700);p.write_bytes(b);p.chmod(0o600)
body=dict(source_commit=q['source_commit'],files_sha256={n:hashlib.sha256(b).hexdigest()for n,b in files.items()},full_paper_complete=False)
bundle=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest()
(r/'private/stage-receipt.json').write_text(json.dumps(dict(body,bundle_sha256=bundle),sort_keys=True,indent=2)+'\n')
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(r)+':/home/shihao/projects/EgoEMG-Classic-Canonical-20261026/.deps',EGOEMG_UPSTREAM='/home/shihao/projects/EgoEMG-Reproduction/upstream')
with(r/'private/recorder.stdout').open('xb')as log:p=subprocess.Popen(['/home/shihao/projects/EgoEMG-Reproduction/.runtime/env/bin/python','-u','-B',str(r/'private/recorder.py')],cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
for _ in range(200):
 if(r/'private/execution-state.json').exists():break
 assert p.poll()is None;time.sleep(.05)
s=json.loads((r/'private/execution-state.json').read_text())
def live(i):
 p=Path('/proc',str(i['pid']))
 try:z=(p/'stat').read_text().rsplit(')',1)[1].split();return z[19]==str(i['start_ticks'])and z[0]!='Z'and p.stat().st_uid==os.getuid()
 except FileNotFoundError:return False
assert s['wrapper']['pid']==p.pid and all(live(s[k])for k in('wrapper','child'))
print(json.dumps(dict(root=str(r),source_commit=q['source_commit'],bundle_sha256=bundle,actual_state=s,matching_original_owners_live=True,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scientific_eligible=False,full_paper_complete=False)))
