from pathlib import Path
import hashlib,json,os,sys
q=json.load(sys.stdin);r=Path(q['root']);sys.path.insert(0,str(r))
from egoemg_repro.emg2pose_memory_process import same_process
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
s=json.loads((r/'private/execution-state.json').read_text());m=json.loads((r/'private/stage-receipt.json').read_text())
assert s['status']=='complete'and s['actual_exit_code']==0
assert all(s[k]==q['actual_state'][k]and not same_process(s[k])for k in('wrapper','child'))
assert m['bundle_sha256']==q['bundle_sha256']==hashlib.sha256(json.dumps({k:v for k,v in m.items()if k!='bundle_sha256'},sort_keys=True,separators=(',',':')).encode()).hexdigest()
v=json.loads((r/'private/workflow-result.json').read_text())
assert v['source_commit']==q['source_commit']and v['bundle_sha256']==m['bundle_sha256']
assert len(v['actual_owned_stages'])==5 and v['all_owned_consumers_exited']
for stage in v['actual_owned_stages']:
 assert stage['status']=='success'and stage['worker_exit_code']==0 and stage['all_owned_consumers_exited']
 assert all(not same_process(stage[k])for k in('worker','guardian'))
for n,h in m['files_sha256'].items():assert sha(r/n)==h,n
identities={}
for group in('engineering','full'):
 paths=[r/('private/'+group+'-'+suffix+'.json')for suffix in('a','b')]
 assert [sha(p)for p in paths]==v[group+'_receipt_files_sha256']
 a,b=[json.loads(p.read_text())for p in paths];assert a==b
 assert a['sha256']==hashlib.sha256(json.dumps({k:x for k,x in a.items()if k!='sha256'},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 identities[group]=a
assert identities['full']==v['full_identity']
assert v['actual_independent_engineering_admissions']==2 and v['actual_full_legacy_admissions']==2 and v['actual_full_payload_hash_passes']==4
f=identities['full'];assert f['counts']==dict(train=62470,val=1052)and f['registered_full_legacy']is True
assert f['future_fusion_partition_content_sha256']=='44e9ebc8a2f63a79699c5a976bf2717b0fe7a376427c7c46f538d0745c2b4bd0'
assert f['full_payload_content_hashed']and f['all_payload_bytes_rehashed_after_full_target_scan']
assert f['consumed_emg_nonfinite_entries']==f['full_trajectory_target_nonfinite_entries']==0
assert all(x['actual_learned_models_constructed']==0 and x['optimizer_updates']==0 and x['cuda_initialized']is False for x in v['actual_cli_receipts'])
assert all(x['all_three_rng_domains_unchanged']and x['optimizer_constructions']==0 for x in v['actual_cli_receipts'][1:])
assert not v['trained_initializer_complete']and not v['full_paper_complete']and'torch'not in sys.modules
print(json.dumps(dict(actual_terminal_state=s,raw_workflow=v,raw_workflow_file_sha256=sha(r/'private/workflow-result.json'),engineering_identity=identities['engineering'],all_twelve_original_owners_closed=True,all_capsule_and_receipt_bytes_after_exit_exact=True,collector_torch_unimported=True)))
