from pathlib import Path
import datetime,hashlib,json,os,shutil,sys,time
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from egoemg_repro.emg2pose_memory_process import run_owned_stage,same_process,process_identity
from egoemg_repro.classic_emg_cohort import _StatGuard
q=json.loads((R/'private/request.json').read_text());m=json.loads((R/'private/stage-receipt.json').read_text());parent=process_identity(os.getppid());began=time.monotonic()
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
pins=_StatGuard([*[R/n for n in m['files_sha256']],R/'private/stage-receipt.json',Path(q['data'])/'manifest.json',Path(q['data'])/'metadata.npz'])
def guard():
 assert 'torch'not in sys.modules and same_process(parent);pins.check()
 assert shutil.disk_usage('/data').free>15*1024**3
 assert int(next(x.split()[1]for x in Path('/proc/meminfo').read_text().splitlines()if x.startswith('MemAvailable:')))*1024>32*1024**3
for n,h in m['files_sha256'].items():assert sha(R/n)==h,n
owned=[];logs=[]
for label in('setup','engineering-a','engineering-b','full-a','full-b'):
 guard();print(json.dumps(dict(phase=label,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())),flush=True)
 stage=run_owned_stage([sys.executable,'-B',str(R/'private/input-cli.py'),label],R/('private/owned-'+label),descriptors={},guard=guard,environment=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1'),poll_seconds=2.,terminate_grace=10.)
 assert stage['status']=='success'and stage['worker_exit_code']==0 and stage['all_owned_consumers_exited']and all(not same_process(stage[k])for k in('worker','guardian'))
 owned.append(stage);log=json.loads((R/('private/owned-'+label+'/worker.log')).read_text().splitlines()[-1]);logs.append(log);guard()
for group in('engineering','full'):
 a=json.loads((R/('private/'+group+'-a.json')).read_text());b=json.loads((R/('private/'+group+'-b.json')).read_text());assert a==b
for n,h in m['files_sha256'].items():assert sha(R/n)==h,n
guard();value=dict(format='actual_rn18_cotrain_independent_engineering_and_full_input_admissions_v1',source_commit=m['source_commit'],bundle_sha256=m['bundle_sha256'],actual_owned_stages=owned,actual_cli_receipts=logs,
 actual_independent_engineering_admissions=2,actual_full_legacy_admissions=2,actual_full_payload_hash_passes=4,
 full_identity=b,full_receipt_files_sha256=[sha(R/'private/full-a.json'),sha(R/'private/full-b.json')],engineering_receipt_files_sha256=[sha(R/'private/engineering-a.json'),sha(R/'private/engineering-b.json')],
 all_full_trajectory_input_identities_reopened_exact=True,all_owned_consumers_exited=True,all_capsule_sources_after_exit_exact=True,
 learned_pose_models_constructed=0,optimizer_updates=0,cuda_initialized=False,trained_initializer_complete=False,scientific_settings_added=0,full_paper_complete=False,seconds=time.monotonic()-began)
with(R/'private/workflow-result.json').open('x')as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(status='independent-full-rn18-cotrain-inputs-closed',identity_sha256=b['sha256'])),flush=True)
