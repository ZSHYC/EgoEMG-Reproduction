"""Existing stage code transported locally on the authorized server."""
from pathlib import Path
import base64,contextlib,datetime,hashlib,io,json,os,subprocess,sys,time,traceback
B=Path(__file__).resolve().parent;STATE=B/'bootstrap-state.json';SOURCE='ab3e26f4efea63c0ca295199f6529b5037ac2948'
DATA='/home/shihao/projects/EgoEMG-Reproduction/data/legacy';UPSTREAM='/home/shihao/projects/EgoEMG-Reproduction/upstream'
RUNTIME='/home/shihao/projects/EgoEMG-Reproduction/.runtime/env/bin/python';DEPS='/home/shihao/projects/EgoEMG-Classic-Canonical-20261026/.deps'
ROOTS=dict(data=Path('/data/shihao/egoemg-rn18-cotrain-full-inputs-fixed-20261101'),cpu=Path('/data/shihao/egoemg-rn18-cotrain-cpu-recovery-fixed-20261101'),gpu=Path('/data/shihao/egoemg-rn18-cotrain-original-full-cli-20261101'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def identity(pid):
 p=Path('/proc',str(pid));s=(p/'stat').read_text().rsplit(')',1)[1].split()
 return dict(pid=pid,start_ticks=s[19],uid=p.stat().st_uid)
def live(i):
 try:
  p=Path('/proc',str(i['pid']));s=(p/'stat').read_text().rsplit(')',1)[1].split()
  return s[19]==str(i['start_ticks'])and s[0]!='Z'and p.stat().st_uid==os.getuid()
 except(FileNotFoundError,ProcessLookupError):return False
def write(value):
 tmp=STATE.with_suffix('.writing')
 with tmp.open('w')as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 tmp.replace(STATE)
def verify():
 m=json.loads((B/'manifest.json').read_text());assert m['source_commit']==SOURCE
 for n,h in m['files_sha256'].items():
  assert not Path(n).is_absolute()and'..'not in Path(n).parts and sha(B/n)==h,n
  if n.endswith('.py'):compile((B/n).read_bytes(),n,'exec')
 for n,h in json.loads((B/'review.json').read_text())['final_source_files_sha256'].items():assert sha(B/'source'/n)==h,n
 assert'torch'not in sys.modules
 return m
def payload(role):
 files={}
 for p in(B/'source').rglob('*'):
  if not p.is_file():continue
  n=str(p.relative_to(B/'source'))
  if role=='gpu'and not n.startswith('egoemg_repro/'):continue
  if role=='data'and n.startswith('scripts/'):continue
  files[n]=p.read_bytes()
 files['private/recorder.py']=(B/'ops/recorder.py').read_bytes()
 files['private/runtime-probe.py']=(B/('ops/'+role+'-controller.py')).read_bytes()
 if role=='data':files['private/input-cli.py']=(B/'ops/data-input-cli.py').read_bytes()
 elif role=='cpu':files['private/cpu-cli.py']=(B/'ops/cpu-cpu-cli.py').read_bytes()
 else:files['private/cpu-accept.py']=(B/'ops/gpu-cpu-accept.py').read_bytes()
 req=dict(upstream=UPSTREAM)
 if role=='data':req['data']=DATA
 if role!='gpu':files['private/request.json']=(json.dumps(req,sort_keys=True,indent=2)+'\n').encode()
 q=dict(source_commit=SOURCE,files={n:base64.b64encode(b).decode()for n,b in files.items()})
 if role=='gpu':q['review']=json.loads((B/'review.json').read_text())
 return q
def stage(role):
 q=payload(role);old=sys.stdin;sys.stdin=io.StringIO(json.dumps(q));out=io.StringIO()
 try:
  with contextlib.redirect_stdout(out):exec(compile((B/('ops/stage-'+role+'.py')).read_bytes(),'server-stage-'+role,'exec'),{'__name__':'server_transport'})
 finally:sys.stdin=old
 v=json.loads(out.getvalue());assert v['root']==str(ROOTS[role])
 with(B/(role+'-launch.json')).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 return v
def collect(role,q):
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=DEPS)
 out=B/(role+'-postexit.json');err=B/(role+'-postexit.stderr')
 with out.open('x')as o,err.open('x')as e:
  p=subprocess.run([RUNTIME,'-B','-c',(B/('ops/collect-'+role+'.py')).read_text()],input=json.dumps(q),text=True,stdout=o,stderr=e,env=env,timeout=90)
 assert p.returncode==0,role+' post-exit verification failed; inspect '+str(err)
 v=json.loads(out.read_text());assert v['all_capsule_and_receipt_bytes_after_exit_exact']if role=='data'else v['all_capsule_and_output_bytes_after_exit_exact']
 return v
def preflight():
 verify();assert Path(RUNTIME).is_file()and os.access(RUNTIME,os.X_OK)
 assert Path(DATA).is_dir()and Path(DATA).stat().st_uid==os.getuid(),'run as the authorized dataset owner'
 assert subprocess.check_output(['git','-C',UPSTREAM,'rev-parse','HEAD'],text=True).strip()=='f7cbd048b7092139852270491d3859cd472e0311'
 assert Path('/data/shihao/egoemg-native-resnet18-full-cli-20261101/private/execution-state.json').is_file()
 assert all(not p.exists()for p in ROOTS.values()),'inspect existing registered handles instead of starting duplicates'
 assert not STATE.exists(),'existing bootstrap must be inspected, never automatically retried'
def drive():
 for _ in range(100):
  if STATE.exists():break
  time.sleep(.01)
 current=json.loads(STATE.read_text());assert current['status']=='starting'and current['pid']==os.getpid()
 current.update(status='preparing',process_identity=identity(os.getpid()));write(current)
 launches={role:stage(role)for role in('data','cpu')};current.update(launches=launches);write(current)
 waiting=set(launches)
 while waiting:
  verify()
  for role in list(waiting):
   v=json.loads((ROOTS[role]/'private/execution-state.json').read_text());expected=launches[role]['actual_state']
   assert all(v[k]==expected[k]for k in('wrapper','child')),'registered stage identity changed'
   if v['status']=='running':assert all(live(v[k])for k in('wrapper','child'));continue
   assert v['status']=='complete'and v['actual_exit_code']==0 and all(not live(v[k])for k in('wrapper','child'))
   collect(role,launches[role]);waiting.remove(role)
  if waiting:time.sleep(5)
 launches['gpu']=stage('gpu');current.update(status='gpu_workflow_queued',launches=launches,full150_complete=False,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());write(current)
 print(json.dumps(dict(status=current['status'],gpu_root=str(ROOTS['gpu']),full150_complete=False)),flush=True)
def main():
 if sys.argv[1:]==['--verify']:
  m=verify();print(json.dumps(dict(package_verified=True,source_commit=SOURCE,files=len(m['files_sha256']),server_work_started=False)));return
 if sys.argv[1:]==['--drive']:
  try:drive()
  except BaseException:
   current=json.loads(STATE.read_text());current.update(status='failed',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());write(current);traceback.print_exc();raise
  return
 if sys.argv[1:]:raise ValueError('use no arguments to stage, or --verify for files only')
 preflight()
 with(B/'bootstrap.log').open('xb')as log:
  env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1')
  p=subprocess.Popen([sys.executable,'-u','-B',str(Path(__file__).resolve()),'--drive'],cwd=B,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  write(dict(status='starting',pid=p.pid,source_commit=SOURCE,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_paper_complete=False))
 for _ in range(100):
  value=json.loads(STATE.read_text())
  if value['status']!='starting':break
  assert p.poll()is None;time.sleep(.1)
 assert value['status']!='failed'and live(value['process_identity'])
 print(json.dumps(dict(bootstrap_started=True,registered_process=value['process_identity'],state_file=str(STATE),formal_gpu_fit_started=False)))
if __name__=='__main__':main()
